export type CSSValue = {
  value: number;
  unit: string;
}
