export enum ColorSchemeName {
  light = 'vex-style-light',
  default = 'vex-style-default',
  dark = 'vex-style-dark'
}
