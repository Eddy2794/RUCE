import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'vex-tabs-ejemplo',
  templateUrl: './tabs-ejemplo.component.html',
  styleUrls: ['./tabs-ejemplo.component.scss']
})
export class TabsEjemploComponent implements OnInit {

 
  constructor( ) { }

  ngOnInit(): void {
    
  }

}
