import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'vex-error-500',
  templateUrl: './error-500.component.html',
  styleUrls: ['./error-500.component.scss']
})
export class Error500Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
