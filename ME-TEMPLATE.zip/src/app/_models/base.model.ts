export class BaseModel {
  public id?: number;
  public estaActivo?: boolean;
  public createdAt?: string;
  public updatedAt?: string;
}
