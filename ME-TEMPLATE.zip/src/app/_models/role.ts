export enum Role {
    User = 'User',
    Vendedor = "VENDEDOR",
    Admin = 'ADMINISTRADOR'
}