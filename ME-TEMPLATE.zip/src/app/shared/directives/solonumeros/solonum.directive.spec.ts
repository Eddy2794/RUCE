import { SolonumDirective } from './solonum.directive';

describe('SolonumDirective', () => {
  it('should create an instance', () => {
    const directive = new SolonumDirective();
    expect(directive).toBeTruthy();
  });
});
