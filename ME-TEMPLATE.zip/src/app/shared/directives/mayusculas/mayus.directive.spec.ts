import { MayusDirective } from './mayus.directive';

describe('MayusDirective', () => {
  it('should create an instance', () => {
    const directive = new MayusDirective();
    expect(directive).toBeTruthy();
  });
});
