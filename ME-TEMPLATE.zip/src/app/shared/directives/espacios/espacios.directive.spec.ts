import { EspaciosDirective } from './espacios.directive';

describe('EspaciosDirective', () => {
  it('should create an instance', () => {
    const directive = new EspaciosDirective();
    expect(directive).toBeTruthy();
  });
});
