export interface IObjetoModalMultiple {
    nombreModal: string;
    valores: any[]
}